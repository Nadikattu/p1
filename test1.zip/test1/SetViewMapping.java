package test1;

import java.util.HashMap;
import java.util.Set;

public class SetViewMapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap h1=new HashMap();
		//HashMap shallowCopy=new HashMap();
		h1.put("1","Ramya");
		h1.put("2","Jyothi");
		h1.put("3","Nadikattu");
		h1.put("4","UCM");
		System.out.println( h1.values());
		Set s = h1.entrySet();
		  // check set values
		  System.out.println("Set values: " + s);

	}

}
