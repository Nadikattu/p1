package test1;

import java.util.HashMap;

public class ValueOfSpecified {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap h1=new HashMap();
		h1.put("1","Ramya");
		h1.put("2","Jyothi");
		h1.put("3","Nadikattu");
		h1.put("4","UCM");
		System.out.println( h1.values());
		System.out.println("The value of specified key is:" +h1.get("1"));

	}

}
