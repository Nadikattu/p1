package test1;

import java.util.HashMap;

public class Collection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap h1=new HashMap();
		h1.put("1","Ramya");
		h1.put("2","Jyothi");
		h1.put("3","Nadikattu");
		h1.put("4","UCM");
		System.out.println("The collection view is:" +h1.values());
	}

}
