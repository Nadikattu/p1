package test1;

import java.util.HashMap;

public class SpecifiedValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap h1=new HashMap();
		h1.put("1","Ramya");
		h1.put("2","Jyothi");
		h1.put("3","Nadikattu");
		h1.put("4","UCM");
		System.out.println( h1.values());
		if(h1.containsValue("Jyothi"))
		{
			System.out.println("There is a value");
		}
		else
			System.out.println("There is no value");

	}

}
