package test1;

import java.util.HashMap;

public class Empty {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap h1=new HashMap();
		if(h1.isEmpty())
		{
			System.out.println("The map is empty");
		}
		else
		{
			System.out.println("The map is not empty");
		}
     /*    h1.put("1","Ramya");
		h1.put("2","Jyothi");
		h1.put("3","Nadikattu");
		h1.put("4","UCM");
		System.out.println( h1.values());*/
			
}

	

}
