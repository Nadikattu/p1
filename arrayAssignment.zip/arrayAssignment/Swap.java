package arrayAssignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Swap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List a1= new ArrayList();
         a1.add("Ramya");
	        a1.add("Jyothi");
	        a1.add("Texas");
	        a1.add("1");
	        a1.add("2");
	        System.out.println(a1);
	        Collections.swap(a1, 2, 3);
	        System.out.println(a1);
	}

}
