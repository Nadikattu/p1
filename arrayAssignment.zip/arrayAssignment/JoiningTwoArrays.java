package arrayAssignment;

import java.util.ArrayList;

public class JoiningTwoArrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList colors=new ArrayList();
		ArrayList names=new ArrayList();
		ArrayList total=new ArrayList();
		System.out.println("The elements in the first array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			
			System.out.println("The elements in the second array are:");
            names.add("green");
			names.add("yellow");
			names.add("pink");
			System.out.println(names);
			total.add(colors);
			total.add(names);
			System.out.println(total);
			

	}

}
