package arrayAssignment;
import java.util.ArrayList;
import java.util.Iterator;


public class Colour
 {
	 
      
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("hello");
		ArrayList colors=new ArrayList();
	//	Iterator i= values.iterator();
		colors.add("Blue");
		colors.add("white");
		colors.add("red");
		colors.add("orange");
	      System.out.println(colors);
		


}
}
