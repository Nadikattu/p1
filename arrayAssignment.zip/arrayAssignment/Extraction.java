package arrayAssignment;

import java.util.ArrayList;
import java.util.List;

public class Extraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List a1= new ArrayList();
         a1.add("Ramya");
	        a1.add("Jyothi");
	        a1.add("Texas");
	        a1.add("1");
	        a1.add("2");
	        System.out.println(a1);
	       // a1.subList(2, 4);
	        System.out.println("The elements in the sublist are:");
	        System.out.println(a1.subList(2, 4));

	}

}
