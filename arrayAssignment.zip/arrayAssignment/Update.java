package arrayAssignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Update {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  ArrayList a1=new ArrayList(5);
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the elements in the arraylist");
			System.out.println("");
		     for(int i=0;i<=5;i++)
		     {
		    	 String s=sc.nextLine();
	        	a1.add(s);
		     }
		     a1.set(2, 5);
		     System.out.println("The values in the arraylist are:");
				Iterator i= a1.iterator();
				while(i.hasNext())
				{
				   System.out.println(i.next());
		        }
          //  a1.set(2, 5);
	}

}
