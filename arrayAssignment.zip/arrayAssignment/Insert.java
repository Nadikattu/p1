package arrayAssignment;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Insert {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		List values= new ArrayList();
		values.add("123");
		values.add("456");
		values.add(0, 678);
        Iterator i =values.iterator();
        while(i.hasNext())
        {
        	System.out.println(i.next());
        }
	}

}
