package arrayAssignment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Sorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList colors=new ArrayList();
		//	Iterator i= colors.iterator();
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
		      System.out.println(colors);
		      Collections.sort(colors);
		      System.out.println(colors);
	       

	}

}
