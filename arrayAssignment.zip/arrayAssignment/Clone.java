package arrayAssignment;

import java.util.ArrayList;

public class Clone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList colors=new ArrayList();
		System.out.println("The elements in the array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			colors.clone();
			System.out.println(colors);

	}

}
