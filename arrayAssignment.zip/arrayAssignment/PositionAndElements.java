package arrayAssignment;

import java.util.ArrayList;
import java.util.List;

public class PositionAndElements {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List colors=new ArrayList();
		//List names=new ArrayList();
		System.out.println("The elements in the first array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			System.out.println(colors.size());
			System.out.println("The index and elements in the list are");
			
				
			for(int i=0;i<colors.size();i++)
			{
				System.out.print(i);
				System.out.print("   ");
				System.out.println(colors.get(i));
				
			}
		//	System.out.println(colors.get());
			
	}

}
