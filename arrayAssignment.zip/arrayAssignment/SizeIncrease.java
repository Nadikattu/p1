package arrayAssignment;

import java.util.ArrayList;

public class SizeIncrease {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList colors=new ArrayList(4);
		ArrayList names=new ArrayList();
		System.out.println("The elements in the first array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			colors.ensureCapacity(7);
			colors.add("green");
			colors.add("red");
			colors.add("black");
			colors.add("purple");
			colors.add("grey");
			System.out.println(colors);
			

	}

}
