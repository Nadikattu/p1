package arrayAssignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Searching {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  List a1=new ArrayList();
		  Scanner sc=new Scanner(System.in);
		    String s ;
	        a1.add("Ramya");
	        a1.add("Jyothi");
	        a1.add("Texas");
	        a1.add("1");
	        a1.add("2");
	        System.out.println(a1);
	        System.out.println("Enter a element to search");
	        s=sc.next();
	        if (a1.contains(s))
	        System.out.println("The element present in the array");
	        else
	        	System.out.println("The element doesnot present in the array");
	        
	        
	}

}
