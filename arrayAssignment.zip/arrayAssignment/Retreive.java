package arrayAssignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Retreive {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List values= new ArrayList();
		values.add("123");
		values.add("456");
		values.add("678");
     
       
      	System.out.println(values.get(1));
	}

	}


