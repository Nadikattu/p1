package arrayAssignment;

import java.util.ArrayList;
import java.util.List;

public class Remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        List a1=new ArrayList();
        a1.add("Ramya");
        a1.add("Jyothi");
        a1.add("Texas");
        a1.add("1");
        a1.add("2");
        System.out.println(a1);
        a1.remove(2);
        System.out.println("");
        System.out.println(a1);
        
	}

}
