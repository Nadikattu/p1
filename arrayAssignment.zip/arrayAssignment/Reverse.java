package arrayAssignment;

import java.util.ArrayList;
import java.util.Collections;

public class Reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList colors=new ArrayList();
		//	Iterator i= colors.iterator();
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			Collections.reverse(colors);
			System.out.println("The elements in the reverse order are:");
           System.out.println(colors);
	}

}
