package arrayAssignment;

import java.util.ArrayList;
import java.util.List;

public class Copying {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 List a1=new ArrayList();
		 List a2=new ArrayList();
		 a1.add("Ramya");
	        a1.add("Jyothi");
	        a1.add("Texas");
	        a1.add("1");
	        a1.add("2");
	        System.out.println(a1);
	     //   a1.listIterator();
	        a2=a1;
	        System.out.println("The elements in a2 is:");
	        System.out.println(a2);
	}

}
