package arrayAssignment;

import java.util.ArrayList;
import java.util.List;

public class Comparision {


	    public static  boolean compareList(List colors,List names){
	        return colors.toString().contentEquals(names.toString())?true:false;
	    }

	public static void main(String[]  args)
	{
		// TODO Auto-generated method stub
		ArrayList colors=new ArrayList();
		ArrayList names=new ArrayList();
		System.out.println("The elements in the first array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			
			System.out.println("The elements in the second array are:");
            names.add("orange");
			names.add("yellow");
			names.add("pink");
			System.out.println(names);
			
			System.out.println("output:"  +compareList(colors,names));
		  
		 

	}

}

