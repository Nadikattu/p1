package arrayAssignment;

import java.util.ArrayList;

public class Trim {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList colors=new ArrayList();
		ArrayList names=new ArrayList();
		System.out.println("The elements in the first array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			colors.trimToSize();
			System.out.println(colors);

	}

}
