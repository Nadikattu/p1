package arrayAssignment;

import java.util.ArrayList;

public class ListEmpty {

	public static void main(String[] args) {
		ArrayList colors=new ArrayList();
		if(colors.isEmpty())
			System.out.println("The arraylist is empty");
		else
			System.out.println("The arraylist has elements");
	/*	System.out.println("The elements in the first array are:");
			colors.add("Blue");
			colors.add("white");
			colors.add("red");
			colors.add("orange");
			System.out.println(colors);
			*/
		// TODO Auto-generated method stub

	}

}
